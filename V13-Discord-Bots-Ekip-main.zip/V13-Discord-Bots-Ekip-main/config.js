﻿﻿const config = {
  "botStatus": ["Developed By 𐱃𐰍𐰺𐰴"],
  "prefix": ["!", "."],
  "token": "MTAzMDA2MzgzNDM3Mjc4NDI1OQ.Gw_7YX.3lrw04f_oTOe6WHnoFsDuTtVxRqF37neKsEpNI",
  "mongoose": "",
  "botOwners": ["514943676061974529"],
  "guildID": "1052944019539378267",
  
  "emojis": {
    "yes_name": "yes_𐱃𐰍𐰺𐰴",
    "no_name": "no_𐱃𐰍𐰺𐰴",
    "mute_name": "𐱃𐰍𐰺𐰴_mute"
  }
  }
  
  module.exports = config;
  
  