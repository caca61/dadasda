# V13-Discord-Bot-Ekip

Selam CANZADENİN BOTUNA ETİKET TAGI EKLEMEYEN A-BOTCULAR soul ve goko attığı projeden star kasiomus yok 50 Star'da hoşgeldin mesajı eventler fln prim yok k4peklere hoşgeldin mesajı kontrol vesayre alın kullanin iyi günler... Meriaz kardesimin codeleri ile yapiolar bide ssler altta 
10 20 starda burda bot

# Meriaza yardımları için teşekkürler...

#Meriaza yardımları için teşekkürler.

Bide Biz Etiket Tagı ekledik yazmışlar aynen kanka ;D
![image](https://cdn.discordapp.com/attachments/887034843089748008/996334623145611305/unknown.png)
![image](https://cdn.discordapp.com/attachments/887034843089748008/996332455181164604/unknown.png)

# Bot Ait Bir Kaç Resim.
![image](https://cdn.discordapp.com/attachments/887034843089748008/996335447489912973/Adsz.png)
![image](https://cdn.discordapp.com/attachments/887034843089748008/996335917075812394/Adsz.png)
![image](https://cdn.discordapp.com/attachments/887034843089748008/996338144578392165/Adsz.png)
![image](https://cdn.discordapp.com/attachments/887034843089748008/996342384990363658/Adsz.png)


